function mayorNum() {
    var num = parseInt (document.getElementById("num1").value);
    var num2 = parseInt (document.getElementById("num2").value);
    if ( => ) {
        if (num2 <= ) {
            if ( == ) {
                alert ("Los numeros son iguales");
            }else{
                alert ("El num1 es mayor");
            }
        }else{
             ("El num2 es mayor");
        }
    }{
        alert ("Uno de los numeros no se relleno");
    }

}